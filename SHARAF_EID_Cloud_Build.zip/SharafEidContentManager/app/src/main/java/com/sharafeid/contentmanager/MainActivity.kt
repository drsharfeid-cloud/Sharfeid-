package com.sharafeid.contentmanager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.room.*
import androidx.room.Room
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

private val Ink = Color(0xFF17191D)
private val Panel = Color(0xFF24272D)
private val Red = Color(0xFFB8323A)
private val Gold = Color(0xFFD5A45F)
private val Cream = Color(0xFFF2EEE8)

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val category: String = "تحضير",
    val done: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks ORDER BY done ASC, createdAt DESC")
    fun observeAll(): kotlinx.coroutines.flow.Flow<List<TaskEntity>>
    @Insert suspend fun insert(task: TaskEntity)
    @Update suspend fun update(task: TaskEntity)
    @Delete suspend fun delete(task: TaskEntity)
    @Query("SELECT * FROM tasks") suspend fun all(): List<TaskEntity>
    @Query("DELETE FROM tasks") suspend fun clear()
}

@Database(entities = [TaskEntity::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun taskDao(): TaskDao
    companion object {
        @Volatile private var INSTANCE: AppDb? = null
        fun get(context: android.content.Context): AppDb =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(context.applicationContext, AppDb::class.java, "sharaf_eid.db").build().also { INSTANCE = it }
            }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = AppDb.get(this).taskDao()
        setContent { SharafApp(dao) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SharafApp(dao: TaskDao) {
    val scope = rememberCoroutineScope()
    val context = androidx.compose.ui.platform.LocalContext.current
    val tasks by dao.observeAll().collectAsState(initial = emptyList())
    var tab by remember { mutableStateOf("الرئيسية") }
    var newTitle by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("تحضير") }
    var showAdd by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf("") }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch {
            val arr = JSONArray()
            dao.all().forEach { t ->
                arr.put(JSONObject().put("title", t.title).put("category", t.category).put("done", t.done).put("createdAt", t.createdAt))
            }
            context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(arr.toString()) }
            info = "تم إنشاء النسخة الاحتياطية"
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            runCatching {
                val raw = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: 
                val arr = JSONArray(raw)
                dao.clear()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    dao.insert(TaskEntity(title=o.getString("title"), category=o.optString("category","تحضير"), done=o.optBoolean("done",false), createdAt=o.optLong("createdAt",System.currentTimeMillis())))
                }
                info = "تم استيراد النسخة الاحتياطية"
            }.onFailure { info = "تعذر استيراد الملف: ${it.message}" }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Red, secondary = Gold, background = Ink, surface = Panel,
        onPrimary = Color.White, onBackground = Cream, onSurface = Cream
    )) {
        Scaffold(
            containerColor = Ink,
            topBar = {
                TopAppBar(
                    title = { Column { Text("SHARAF EID", color = Cream); Text("CONTENT MANAGER", style = MaterialTheme.typography.labelSmall, color = Gold) } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Ink)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    listOf("الرئيسية", "المهام", "الإعدادات").forEach { item ->
                        NavigationBarItem(selected = tab == item, onClick = { tab = item },
                            icon = { Icon(when(item) { "الرئيسية" -> Icons.Default.Home; "المهام" -> Icons.Default.CheckCircle; else -> Icons.Default.Settings }, null) },
                            label = { Text(item) })
                    }
                }
            },
            floatingActionButton = {
                if (tab == "المهام" || tab == "الرئيسية") {
                    FloatingActionButton(onClick = { showAdd = true }, containerColor = Red, contentColor = Color.White) {
                        Icon(Icons.Default.Add, contentDescription = "إضافة مهمة")
                    }
                }
            }
        ) { padding ->
            when (tab) {
                "الرئيسية" -> Dashboard(tasks, Modifier.padding(padding), onTasks = { tab = "المهام" })
                "المهام" -> TaskScreen(tasks, dao, Modifier.padding(padding))
                else -> SettingsScreen(
                    Modifier.padding(padding),
                    onExport = { exportLauncher.launch("sharaf_eid_backup.json") },
                    onImport = { importLauncher.launch(arrayOf("application/json", "text/*")) }
                )
            }
        }
    }

    if (showAdd) {
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("مهمة جديدة") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = newTitle, onValueChange = { newTitle = it }, label = { Text("اسم المهمة") }, singleLine = true)
                    Text("التصنيف")
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("تحضير","تصوير","مونتاج","نشر").forEach {
                            FilterChip(selected = category == it, onClick = { category = it }, label = { Text(it) })
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (newTitle.isNotBlank()) scope.launch { dao.insert(TaskEntity(title = newTitle.trim(), category = category)) }
                    newTitle = ""; category = "تحضير"; showAdd = false
                }) { Text("حفظ") }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("إلغاء") } }
        )
    }
    if (info.isNotBlank()) AlertDialog(onDismissRequest = { info = "" }, confirmButton = { TextButton(onClick = { info = "" }) { Text("حسناً") } }, text = { Text(info) })
}

@Composable
fun Dashboard(tasks: List<TaskEntity>, modifier: Modifier, onTasks: () -> Unit) {
    val done = tasks.count { it.done }
    val percent = if (tasks.isEmpty()) 0 else done * 100 / tasks.size
    Column(modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("مساحة شرف عيد", color = Gold, style = MaterialTheme.typography.labelLarge)
                Text("خلّي أفكارك تتحول لمحتوى.", style = MaterialTheme.typography.headlineSmall, color = Cream)
                Text("متابعة الإنتاج خطوة بخطوة", color = Cream.copy(alpha=.7f))
                LinearProgressIndicator(progress = { percent / 100f }, modifier = Modifier.fillMaxWidth(), color = Gold, trackColor = Ink)
                Text("$percent% إنجاز • $done من ${tasks.size} مهمة", color = Gold)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("كل المهام", tasks.size.toString(), Modifier.weight(1f))
            StatCard("المتبقي", (tasks.size-done).toString(), Modifier.weight(1f))
        }
        Button(onClick = onTasks, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Red)) {
            Text("افتح قائمة المهام")
        }
        Text("تذكيرك: جلسات المحتوى بعد 9:00 مساءً. خذ راحتك ولا تضغط على نفسك.", color = Cream.copy(alpha=.7f))
    }
}

@Composable
fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp)) { Text(value, style = MaterialTheme.typography.headlineMedium, color = Gold); Text(label, color = Cream) }
    }
}

@Composable
fun TaskScreen(tasks: List<TaskEntity>, dao: TaskDao, modifier: Modifier) {
    val scope = rememberCoroutineScope()
    Column(modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Text("مهام الإنتاج", style = MaterialTheme.typography.headlineSmall, color = Cream, modifier = Modifier.padding(vertical = 12.dp))
        if (tasks.isEmpty()) Text("ما عندك مهام حالياً. اضغط + لإضافة أول مهمة.", color = Cream.copy(alpha=.7f))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 90.dp)) {
            items(tasks, key = { it.id }) { task ->
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = task.done, onCheckedChange = { checked -> scope.launch { dao.update(task.copy(done=checked)) } }, colors = CheckboxDefaults.colors(checkedColor = Gold))
                        Column(Modifier.weight(1f)) {
                            Text(task.title, color = if(task.done) Cream.copy(alpha=.45f) else Cream)
                            Text(task.category, color = Gold, style = MaterialTheme.typography.labelSmall)
                        }
                        IconButton(onClick = { scope.launch { dao.delete(task) } }) { Icon(Icons.Default.Delete, null, tint = Red) }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(modifier: Modifier, onExport: () -> Unit, onImport: () -> Unit) {
    Column(modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("الإعدادات والنسخ الاحتياطي", style = MaterialTheme.typography.headlineSmall)
        Text("البيانات محفوظة محلياً على هذا الهاتف.", color = Gold)
        Button(onClick = onExport, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Red)) {
            Icon(Icons.Default.Upload, null); Spacer(Modifier.width(8.dp)); Text("تصدير نسخة احتياطية")
        }
        OutlinedButton(onClick = onImport, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Download, null); Spacer(Modifier.width(8.dp)); Text("استعادة نسخة احتياطية")
        }
        Text("احتفظ بنسخة احتياطية قبل حذف التطبيق أو تغيير الهاتف.", color = Cream.copy(alpha=.7f))
        Text("الإصدار 1.0.0", color = Gold)
    }
}

